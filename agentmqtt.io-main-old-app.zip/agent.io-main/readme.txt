
Simple HTML calculation form
https://codepen.io/prasanthmj/pen/pogWrXN

for sub category
https://www.studentstutorial.com/javascript/subcategory-list-show.php
https://www.studentstutorial.com/javascript/country-state-city-select.php


for multy variable to jonconversion

https://stackoverflow.com/questions/12979335/creating-json-object-with-variables

html javascript mysql
https://codewithmark.com/javascript-storage-like-mysql



to use loacl variable in opther function

var MyApp = {}; // Globally scoped object

function foo(){
    MyApp.color = 'green';
}

function bar(){
    alert(MyApp.color); // Alerts 'green'
} 

//###################################################################

{"BEAT":"","SHOP":"","SALT-QTY":"","MUSTARD-QTY":"","GEERA-QTY":"","VENTHYAM-QTY":""}


wss issue 
###############
https://github.com/eclipse/paho.mqtt.javascript/issues/187#issuecomment-594450347

mqtt broakers list
!!!!!!!!!!!!!!!!!!
https://github.com/mqtt/mqtt.org/wiki/public_brokers

############################################################

https://www.npmjs.com/package/mqtt

browserMqtt.js

https://docs.emqx.io/en/broker/v4.3/development/javascript.html#mqtt-js-usage-example






